
import time

# Minimum Spanning Tree using Kruskal's Algorithm

# Function to find the parent of a vertex
def find(parent, vertex):
    if parent[vertex] != vertex:
        parent[vertex] = find(parent, parent[vertex])
    return parent[vertex]


# Function to join two sets
def union(parent, rank, u, v):
    root_u = find(parent, u)
    root_v = find(parent, v)

    if root_u != root_v:
        if rank[root_u] < rank[root_v]:
            parent[root_u] = root_v
        elif rank[root_u] > rank[root_v]:
            parent[root_v] = root_u
        else:
            parent[root_v] = root_u
            rank[root_u] += 1
        return True

    return False


# Main program
print("Minimum Spanning Tree using Kruskal's Algorithm")

n = int(input("Enter number of vertices: "))
m = int(input("Enter number of edges: "))

edges = []

print("Enter each edge as: source destination weight")
print("Use vertex numbers from 0 to", n - 1)

for i in range(m):
    u, v, weight = map(
        int, input(f"Enter edge {i + 1}: ").split()
    )
    edges.append((weight, u, v))

# Start measuring execution time
start_time = time.perf_counter()

# Sort edges by weight
edges.sort()

parent = list(range(n))
rank = [0] * n

mst = []
total_cost = 0

# Select edges without creating a cycle
for weight, u, v in edges:
    if union(parent, rank, u, v):
        mst.append((u, v, weight))
        total_cost += weight

        if len(mst) == n - 1:
            break

end_time = time.perf_counter()

# Display result
if n <= 0:
    print("Number of vertices must be positive.")
elif len(mst) != n - 1:
    print("MST cannot be formed. The graph is disconnected.")
else:
    print("\nEdges in the Minimum Spanning Tree:")
    for u, v, weight in mst:
        print(f"{u} -- {v} : weight = {weight}")

    print("Minimum total cost:", total_cost)

print("Execution time:", end_time - start_time, "seconds")
print("Time Complexity: O(E log E)")