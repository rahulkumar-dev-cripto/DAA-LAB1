import time


# Matrix Chain Multiplication using Dynamic Programming
def matrix_chain_multiplication(dimensions):
    n = len(dimensions) - 1

    # dp[i][j] stores the minimum multiplication cost
    # for matrices i through j
    dp = [[0 for _ in range(n)] for _ in range(n)]

    # Chain length
    for length in range(2, n + 1):

        for i in range(n - length + 1):
            j = i + length - 1

            dp[i][j] = float('inf')

            # Try every possible split
            for k in range(i, j):

                cost = (
                    dp[i][k]
                    + dp[k + 1][j]
                    + dimensions[i] * dimensions[k + 1] * dimensions[j + 1]
                )

                if cost < dp[i][j]:
                    dp[i][j] = cost

    return dp[0][n - 1]


# --------------------------------
# User Input
# --------------------------------

n = int(input("Enter number of matrices: "))

dimensions = []

print("\nEnter dimensions of matrices:")

for i in range(n):
    rows = int(input(f"Enter rows of Matrix {i + 1}: "))
    cols = int(input(f"Enter columns of Matrix {i + 1}: "))

    # First matrix stores both dimensions
    if i == 0:
        dimensions.append(rows)

    dimensions.append(cols)


# --------------------------------
# Calculate Execution Time
# --------------------------------

start_time = time.perf_counter()

minimum_cost = matrix_chain_multiplication(dimensions)

end_time = time.perf_counter()

execution_time = end_time - start_time


# --------------------------------
# Output
# --------------------------------

print("\n----- Matrix Chain Multiplication Result -----")

print("Matrix dimensions:", dimensions)

print("Minimum number of scalar multiplications:", minimum_cost)

print("Execution Time:", execution_time, "seconds")

print("\nTime Complexity: O(n^3)")
print("Space Complexity: O(n^2)")