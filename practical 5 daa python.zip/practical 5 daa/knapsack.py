import time

# Function for 0/1 Knapsack using Dynamic Programming
def knapsack(weights, values, capacity):
    n = len(weights)

    # Create DP table
    dp = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]

    # Fill the DP table
    for i in range(1, n + 1):
        for w in range(1, capacity + 1):

            # If current item can fit
            if weights[i - 1] <= w:
                dp[i][w] = max(
                    values[i - 1] + dp[i - 1][w - weights[i - 1]],
                    dp[i - 1][w]
                )
            else:
                dp[i][w] = dp[i - 1][w]

    return dp[n][capacity]


# -------------------------------
# User Input
# -------------------------------

n = int(input("Enter number of items: "))

weights = []
values = []

for i in range(n):
    weight = int(input(f"Enter weight of item {i + 1}: "))
    value = int(input(f"Enter value of item {i + 1}: "))

    weights.append(weight)
    values.append(value)

capacity = int(input("Enter maximum knapsack capacity: "))


# -------------------------------
# Calculate execution time
# -------------------------------

start_time = time.perf_counter()

max_value = knapsack(weights, values, capacity)

end_time = time.perf_counter()

execution_time = end_time - start_time


# -------------------------------
# Output
# -------------------------------

print("\n----- Knapsack Result -----")
print("Weights:", weights)
print("Values:", values)
print("Capacity:", capacity)
print("Maximum Profit:", max_value)
print("Execution Time:", execution_time, "seconds")

print("\nTime Complexity: O(n × W)")
print("Space Complexity: O(n × W)")