import time

# Start execution timer
start_time = time.perf_counter()

# Take input from user
amount = int(input("Enter the amount: "))

# Coin denominations
coins = [10, 5, 2, 1]

# Store the number of each coin
coin_count = {}

remaining = amount

# Find coins
for coin in coins:
    count = remaining // coin

    if count > 0:
        coin_count[coin] = count
        remaining = remaining % coin

# Display result
print("\nCoin Exchange Result:")

total_coins = 0

for coin, count in coin_count.items():
    print(f"₹{coin} coin = {count}")
    total_coins += count

print("Total number of coins =", total_coins)

# End execution timer
end_time = time.perf_counter()

execution_time = end_time - start_time

print(f"Execution time = {execution_time:.8f} seconds")