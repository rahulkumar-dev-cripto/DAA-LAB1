import time
from collections import deque

# BFS function
def bfs(graph, start):
    visited = set()
    queue = deque()

    visited.add(start)
    queue.append(start)

    result = []

    while queue:
        node = queue.popleft()
        result.append(node)

        for neighbour in graph[node]:
            if neighbour not in visited:
                visited.add(neighbour)
                queue.append(neighbour)

    return result


# -----------------------------
# User Input
# -----------------------------

vertices = int(input("Enter number of vertices: "))

# Create graph
graph = {}

for i in range(vertices):
    graph[i] = []

edges = int(input("Enter number of edges: "))

print("\nEnter edges (example: 0 1):")

for i in range(edges):
    u, v = map(int, input(f"Enter edge {i + 1}: ").split())

    graph[u].append(v)
    graph[v].append(u)  # For undirected graph


# Starting vertex
start = int(input("\nEnter starting vertex: "))


# -----------------------------
# BFS Execution
# -----------------------------

start_time = time.perf_counter()

result = bfs(graph, start)

end_time = time.perf_counter()

execution_time = end_time - start_time


# -----------------------------
# Output
# -----------------------------

print("\n----- BFS RESULT -----")

print("BFS Traversal:", result)

print(f"Execution Time: {execution_time:.8f} seconds")

print("Time Complexity: O(V + E)")
print("Space Complexity: O(V)")