import time

# DFS function
def dfs(graph, node, visited, result):
    visited.add(node)
    result.append(node)

    for neighbour in graph[node]:
        if neighbour not in visited:
            dfs(graph, neighbour, visited, result)


# -----------------------------
# User Input
# -----------------------------

vertices = int(input("Enter number of vertices: "))

# Create graph
graph = {}

for i in range(vertices):
    graph[i] = []

edges = int(input("Enter number of edges: "))

print("\nEnter edges (example: 0 1):")

for i in range(edges):
    u, v = map(int, input(f"Enter edge {i + 1}: ").split())

    graph[u].append(v)
    graph[v].append(u)   # For undirected graph


# Starting vertex
start = int(input("\nEnter starting vertex: "))


# -----------------------------
# DFS Execution
# -----------------------------

visited = set()
result = []

start_time = time.perf_counter()

dfs(graph, start, visited, result)

end_time = time.perf_counter()

execution_time = end_time - start_time


# -----------------------------
# Output
# -----------------------------

print("\n----- DFS RESULT -----")

print("DFS Traversal:", result)

print(f"Execution Time: {execution_time:.8f} seconds")

print("Time Complexity: O(V + E)")
print("Space Complexity: O(V)")