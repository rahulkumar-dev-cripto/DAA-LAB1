import time

# Take elements from user
arr = list(map(int, input("Enter elements separated by spaces: ").split()))

# Sort the array
arr.sort()

print("Sorted array:", arr)

# Take search element
key = int(input("Enter element to search: "))

# Start execution time
start_time = time.perf_counter()

# Binary Search
low = 0
high = len(arr) - 1
found = False
position = -1

while low <= high:
    mid = (low + high) // 2

    if arr[mid] == key:
        found = True
        position = mid
        break

    elif arr[mid] < key:
        low = mid + 1

    else:
        high = mid - 1

# Stop execution time
end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time

# Display result
print("\n--- Binary Search Result ---")

if found:
    print("Element found!")
    print("Element:", key)
    print("Position:", position + 1)
else:
    print("Element not found!")

print("Execution Time:", execution_time, "seconds")

# Complexity
print("Best Case Time Complexity: O(1)")
print("Average Case Time Complexity: O(log n)")
print("Worst Case Time Complexity: O(log n)")
print("Space Complexity: O(1)")