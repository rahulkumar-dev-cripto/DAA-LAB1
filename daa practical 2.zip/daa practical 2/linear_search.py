import time

# Take number of elements
n = int(input("Enter number of elements: "))

# Take elements from user
arr = []

print("Enter the elements:")
for i in range(n):
    value = int(input(f"Element {i + 1}: "))
    arr.append(value)

# Take search element
key = int(input("Enter element to search: "))

# Start execution timer
start_time = time.perf_counter()

# Linear Search
found = False
position = -1

for i in range(n):
    if arr[i] == key:
        found = True
        position = i
        break

# Stop execution timer
end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time

# Display result
print("\n--- Linear Search Result ---")

if found:
    print("Element found!")
    print("Element:", key)
    print("Position:", position + 1)
else:
    print("Element not found!")

print("Execution Time:", execution_time, "seconds")

# Time Complexity
print("Time Complexity: O(n)")
print("Space Complexity: O(1)")