import time

# Take input from user
n = int(input("Enter the number of elements: "))

numbers = []

for i in range(n):
    value = int(input(f"Enter element {i + 1}: "))
    numbers.append(value)

# Start execution timer
start_time = time.perf_counter()

# Iterative calculation: find the sum
total = 0

for i in range(n):
    total = total + numbers[i]

# Stop execution timer
end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time

# Display results
print("\n--- Result ---")
print("Elements:", numbers)
print("Sum:", total)

print("\nTime Complexity: O(n)")
print("Space Complexity: O(n)")
print(f"Execution Time: {execution_time:.10f} seconds")