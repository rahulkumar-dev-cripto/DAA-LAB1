import time

# Recursive function to calculate factorial
def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)


# User input
n = int(input("Enter a number: "))

# Start execution timer
start_time = time.perf_counter()

# Call recursive function
result = factorial(n)

# Stop execution timer
end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time

# Display result
print("\n--- Result ---")
print("Number:", n)
print("Factorial:", result)

print("\nTime Complexity: O(n)")
print("Space Complexity: O(n)")
print(f"Execution Time: {execution_time:.10f} seconds")